﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acme.Common
{
    /// <summary>
    /// Gestiona la salida de un cliente de un local
    /// </summary>
    public static class Cliente
    {
        /// <summary>
        /// Devuelve un string con el nombre del Cliente actual
        /// </summary>
        /// <param name="nombreCliente"></param>
        /// <returns></returns>
		public static string Adios(string nombreCliente)
        {
            return "Que tengas un buen día: " + nombreCliente;
        }

	}
}
