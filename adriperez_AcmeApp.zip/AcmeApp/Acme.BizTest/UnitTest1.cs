using Acme.Common;
using Acme.Biz;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Acme.Common.Tests
{
    [TestClass()]
    public class UnitTest1
    {
        [TestMethod()]
        public void AdiosTest()
        {
            // Arrange
            var expected = "Que tengas un buen d�a: Adrian Perez";

            // Act
            var actual = Cliente.Adios("Adrian Perez");

            // Assert
            Assert.AreEqual(expected, actual);
        }
    }
}

namespace Acme.Biz.Tests
{
    [TestClass()]
    public class UnitTest1
    {
        [TestMethod()]
        public void InfoProductoTest()
        {
            // Arrange
            var producto1 = new Producto();
            producto1.Id = 1;
            producto1.Nombre = "Helado";
            producto1.Precio = 2;

            var expected = "El producto Helado tiene como ID (1) con un precio de 2�";

            // Act
            var actual = producto1.InfoProducto();

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void InfoProductoTestConParametros()
        {
            // Arrange
            var producto2 = new Producto(2, "Sopa", 1);

            var expected = "El producto Sopa tiene como ID (2) con un precio de 1�";

            // Act
            var actual = producto2.InfoProducto();

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void PrecioConDescuentoTest()
        {
            // Arrange
            var producto3 = new Producto(3, "Queso", 25);

            var expected = 15;

            // Act
            var actual = producto3.PrecioConDescuento(producto3.Precio);

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void PrecioConDescuentoTestConParametros()
        {
            // Arrange
            var producto4 = new Producto();
            producto4.Id = 4;
            producto4.Nombre = "Jamon";
            producto4.Precio = 40;

            var expected = 30;

            // Act
            var actual = producto4.PrecioConDescuento(producto4.Precio);

            // Assert
            Assert.AreEqual(expected, actual);
        }
    }
}

