﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Acme.Biz
{
    /// <summary>
    /// Gestiona la informacion del ID, el nombre y el precio de
    /// un producto además de saber su informacion y aplicar descuento
    /// </summary>
    public class Producto
    {
        // Atributos
        private int id;
        private string nombre;
        private double precio;

        // Propiedades
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public double Precio
        {
            get { return precio; }
            set { precio = value; }
        }

        // Constructores
        public Producto()
        {
            Console.WriteLine("Instancia del prodcuto creada");
        }

        public Producto(int idProducto, string nombreProducto, double precioProducto)
        {
            id = idProducto;
            nombre = nombreProducto;
            precio = precioProducto;

            Console.WriteLine("Instancia de producto creada con nombre: " + nombre);
        }

        // Metodos

        /// <summary>
        /// Devuelve un string con el nombre del producto, su ID y el precio que tiene.
        /// </summary>
        /// <returns></returns>
        public string InfoProducto()
        {
            return "El producto " + Nombre + " tiene como ID (" + Id + ") con un precio de " + Precio + "€";
        }

        /// <summary>
        /// Devuelve un double del precio con el descuento de 10 euros aplicado.
        /// </summary>
        /// <param name="precioProducto"></param>
        /// <returns></returns>
        public double PrecioConDescuento(double precioProducto)
        {
            return (Precio -= 10);
        }



    }
}
